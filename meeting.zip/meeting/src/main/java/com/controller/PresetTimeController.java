package com.controller;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.entity.AvailableTime;
import com.entity.PresetDateInfo;
import com.entity.PresetDetail;
import com.service.PresetTimeService;

@Controller
@RequestMapping("/meeting")
public class PresetTimeController {
	@Autowired
	private PresetTimeService service;

	/**
	 * 会议室预定画面初期显示测试用
	 * @return
	 * 会议室预定画面
	 */
	@RequestMapping("/index")
	public String index() {
        return "jsp/presetTime";
    }
	
	/**
	 * 预定按钮点击处理
	 * @return
	 */
	@RequestMapping("/save")
	@ResponseBody
	public Map<String,Object> presetTime(PresetDetail PresetDetail) throws Exception {	
		Map<String,Object> resultMap = new HashMap<>();
		String inputDate = new SimpleDateFormat("yyyy-MM-dd").format(PresetDetail.getSelectDate()); 
		// 预约开始时间
		Timestamp inputStartTime = Timestamp.valueOf(inputDate + " " + PresetDetail.getStrTime() + ":00");
		// 预约结束时间
		Timestamp inputEndTime = Timestamp.valueOf(inputDate + " " + PresetDetail.getEndTime() + ":00");
		// TODO 过去时间不可预约，通过前台非活性实现
		// 不是预约开始时间< 结束时间 NG
		if(inputStartTime.after(inputEndTime) || inputStartTime.equals(inputEndTime)) {
			resultMap.put("save", "NG");
			return resultMap;
		}
		// 查询当天该会议室的预约情况
		List<PresetDateInfo> presetInfoList = service.getPresetDetailList(PresetDetail.getMeetingRoom(), inputDate);
		boolean isOk = false;
		// 当前会议室没有一条预约信息的场合
		if(presetInfoList.isEmpty()) {
			isOk = true;
		} else {
			// 已预约最大时间
			Timestamp maxTime = presetInfoList.get(presetInfoList.size() - 1).getMeetingEndDate();
			// 已预约最小时间
			Timestamp minTime = presetInfoList.get(0).getMeetingStrDate();
			// 预约终了时间<已预约最小时间 OK
			if(inputEndTime.before(minTime) || inputEndTime.equals(minTime)) {
				isOk = true;
			} else if(inputStartTime.after(maxTime) || inputStartTime.equals(maxTime)) {
				// 预约开始时间 > 已预约最大时间　OK
				isOk = true;
			} else {
				// 可预约时间段
				List<AvailableTime> okList = new ArrayList<>();
				for(int i = 0; i < presetInfoList.size() - 1; i++) {
					PresetDateInfo dto = presetInfoList.get(i);
					// 結束時間
					Timestamp endTime = dto.getMeetingEndDate();
					// 下一個開始時間
					Timestamp nextStartTime = presetInfoList.get(i + 1).getMeetingStrDate();
					// 結束時間 != 下一個開始時間时可预约
					if(!endTime.equals(nextStartTime)) {
						AvailableTime availableTime = new AvailableTime();
						availableTime.setAvailableStartTime(endTime);
						availableTime.setAvailableEndTime(nextStartTime);
						okList.add(availableTime);
					}
				}
				if(okList.isEmpty()) {
					resultMap.put("save", "NG");
					return resultMap;
				} else {
					for(AvailableTime availableTime : okList) {
						// 预约开始时间>=可预约开始时间 && 预约结束时间<=可预约结束时间 OK
						if((inputStartTime.after(availableTime.getAvailableStartTime()) || inputStartTime.equals(availableTime.getAvailableStartTime()))
								&& (inputEndTime.before(availableTime.getAvailableEndTime()) || inputEndTime.equals(availableTime.getAvailableEndTime()))) {
							isOk = true;
							break;
						}
					}
				}
			}
			
		}
		
		if(isOk) {
			// TODO OK的场合 INSERT 预约信息保存
			resultMap.put("save", "OK");
		} else {
			resultMap.put("save", "NG");
		}
        return resultMap;
    }
}
