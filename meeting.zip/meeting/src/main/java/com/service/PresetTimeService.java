package com.service;

import java.util.List;

import com.entity.PresetDateInfo;

public interface PresetTimeService {
	public List<PresetDateInfo> getPresetDetailList(String meetingRoom, String meetingDate);

}
